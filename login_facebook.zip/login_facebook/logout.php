<?php
require_once 'config.php';

unset($_SESSION['access_token']);

header("Location:login.php");
?>
