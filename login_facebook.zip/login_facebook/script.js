$(document).ready(function(){
    var API_KEY = "AIzaSyBR825RxQHDtdaom1vnRb4B_NBtcSVukIY"
    var video = ""
    $("#down").submit(function(event){
    event.preventDefault()
    
    var search = $("#Search").val()
    videoSearch(API_KEY,search,10)
    
    })
    function videoSearch(key,search,maxResults){
    
        $.get("https://www.googleapis.com/youtube/v3/search?key=" + key + "&type=video&part=snippet&maxResults=" + maxResults + "&q=" + search,function(data){
            console.log(data)
    
            data.items.forEach(item => {
                video = `
                <iframe width="420" height="315" src="http://www.youtube.com/embed/${item.id.videoId}" frrameborder="0" allowfullscreen></iframe>
                <input type="button" name="submit" onclick="myfun(this)" data-set="http://www.youtube.com/embed/${item.id.videoId}" value="Submit" />           
                `
                $("#videos").append(video)
            });
        } )
    
    }
    
    })

    function myfun(file){
        document.getElementById('fileupload').value = file.getAttribute('data-set');
        console.log(file.getAttribute('data-set'));
        // document.getElementById('fileSubmit').submit();
    }