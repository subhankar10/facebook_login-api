<!DOCTYPE html>
<?php
session_start();

if(!isset($_SESSION['access_token'])){
	header("Location: login.php");
	exit();
}
?>
<html>
<head>
<title>Youtube Search</title>
<!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="script.js"></script>
</head>
<body>
<?php include"header.php"?>

<div class="container">
    <h1>Youtube Video Search</h1>
    <form action="" id="down">
        <div class="form-group">
            <input type="text" class="form-control"id="Search">
        </div>
        <br>
        <div class="form-group">
           <input type="submit" class="btn btn-danger" value="Search"> 
        </div>
    </form>
    <?php 
	if(isset($_POST['submit'])) {
		require 'config.php';
		$data = [
		  'source' => $fb->uploadVideo($_FILES['file']["tmp_name"]),
		];
		try {
		  // Returns a `Facebook\FacebookResponse` object
		  $response = $fb->post('/me/feed', $data,'EAAQs3YkXCCUBAIbS8eEpQdvAZCC4pS89qLRuZB3jLBYL52rPjszSNzPlMuXoWUFbC5fGgx2QH76TLKl6bo5s39kUrTMVzZBwzTDt2ZAJ9YFKNBkRZBTYQjqwHLDr4x6rWizRcMWtKJixK9UMlN76gZBcoOH4EJs9ZBo6gVqx8DPWa5BdsfrRDTsfEIF3OmdYnA3vZBPPk3fqSUihPmJUBBkkSlUjJhKKIK5TizPO6zJaCQZDZD');
		} catch(Facebook\Exceptions\FacebookResponseException $e) {
		  echo 'Graph returned an error: ' . $e->getMessage();
		  exit;
		} catch(Facebook\Exceptions\FacebookSDKException $e) {
		  echo 'Facebook SDK returned an error: ' . $e->getMessage();
		  exit;
		}

		$graphNode = $response->getGraphNode();

		echo 'Photo ID: ' . $graphNode['id'];

	}
?>
    <form name="uploadvideo" method="post" id="fileSubmit" enctype="multipart/form-data">
		<input type="hidden" name="tmp_name" id="fileupload" />
		<input type="button" name="sumit" />
	</form>
    <div class="row">
        <div class="col-12">
            <div id="videos">

            </div>
        </div>
    </div>
</div>

</body>
</html>